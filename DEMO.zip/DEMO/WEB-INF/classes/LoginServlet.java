import java.io.*;
 
import javax.servlet.*;
// import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

// @WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
 
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
         
        String username = request.getParameter("username");
        String password = request.getParameter("password");
         
        System.out.println("username: " + username);
        System.out.println("password: " + password);

        PrintWriter writer = response.getWriter();
         
        String htmlRespone = "<html>";
        htmlRespone += "<h2>Your username is: " + username + "<br/>";      
        htmlRespone += "Your password is: " + password + "</h2>";    
        htmlRespone += "</html>";
         
        writer.println(htmlRespone);
         
    }
 
}


// import java.io.*;
// import javax.servlet.*;
// import javax.servlet.http.*;

// public class RequestInfo extends HttpServlet {

//     public void doGet(HttpServletRequest request, HttpServletResponse response)
//     throws IOException, ServletException
//     {
//         response.setContentType("text/html");
//         PrintWriter out = response.getWriter();
//         out.println("<html>");
//         out.println("<body>");
//         out.println("<head>");
//         out.println("<title>Request Information Example</title>");
//         out.println("</head>");
//         out.println("<body>");
//         out.println("<h3>Request Information Example</h3>");
//         out.println("Method: " + request.getMethod());
//         out.println("Request URI: " + request.getRequestURI());
//         out.println("Protocol: " + request.getProtocol());
//         out.println("PathInfo: " + request.getPathInfo());
//         out.println("Remote Address: " + request.getRemoteAddr());
//         out.println("</body>");
//         out.println("</html>");
//     }

//     /**
//      * We are going to perform the same operations for POST requests
//      * as for GET methods, so this method just sends the request to
//      * the doGet method.
//      */

//     public void doPost(HttpServletRequest request, HttpServletResponse response)
//     throws IOException, ServletException
//     {
//         doGet(request, response);
//     }
// }